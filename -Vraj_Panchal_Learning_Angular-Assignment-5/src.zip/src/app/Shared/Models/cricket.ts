export interface cricket{
  id:number,
  playerName: String,
  playerPosition: String,
  playerJerseyNumber: number,
  playerAge: number;
  isplayertrophies? :boolean,
  pictureimage: string,

}
